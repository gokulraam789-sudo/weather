import React from "react";
import { Bell, ChevronDown } from "lucide-react";
import { BLOCK } from "../data.js";

export default function Header({ title, subtitle }) {
  return (
    <header className="flex items-center gap-4 px-7 py-4 bg-white border-b border-[#E4E2D6]">
      <div>
        <div className="text-[19px] text-[#1C2430] font-medium">{title}</div>
        <div className="text-[12px] text-[#8A93A0]">{subtitle}</div>
      </div>
      <div className="ml-auto flex items-center gap-4">
        <span className="text-[11.5px] font-mono px-2.5 py-1 rounded-full hidden md:inline" style={{ background: "#EAF3EC", color: "#43714B" }}>Data Status: Simulated (Demo)</span>
        <span className="text-[12px] font-mono text-[#5B6472] hidden md:inline">{BLOCK.updated}</span>
        <div className="relative">
          <Bell size={17} color="#5B6472" strokeWidth={1.8} />
          <span className="absolute -top-1.5 -right-1.5 w-3.5 h-3.5 rounded-full text-white text-[9px] flex items-center justify-center" style={{ background: "#A6483A" }}>2</span>
        </div>
        <div className="flex items-center gap-2 pl-3 border-l border-[#E4E2D6]">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[12px] font-medium" style={{ background: "#2E6F95" }}>AO</div>
          <div className="leading-tight hidden sm:block">
            <div className="text-[12.5px] text-[#1C2430]">Agri Officer</div>
            <div className="text-[10.5px] text-[#8A93A0]">Demo User</div>
          </div>
          <ChevronDown size={14} color="#8A93A0" />
        </div>
      </div>
    </header>
  );
}
