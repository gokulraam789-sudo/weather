import React from "react";
import { NavLink } from "react-router-dom";
import {
  CloudRain, LayoutDashboard, Map as MapIcon, Sprout, BarChart3, Bell,
  History as HistoryIcon, Database, Cpu, Settings, ChevronRight,
} from "lucide-react";

const NAV = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard", end: true },
  { to: "/map", icon: MapIcon, label: "Map View" },
  { to: "/forecast", icon: Sprout, label: "Panchayat Forecast" },
  { to: "/charts", icon: BarChart3, label: "Charts & Trends" },
  { to: "/advisories", icon: Bell, label: "Advisories" },
  { to: "/historical", icon: HistoryIcon, label: "Historical Data" },
  { to: "/pipeline", icon: Database, label: "Data Pipeline" },
  { to: "/model", icon: Cpu, label: "Model Info" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

export default function Sidebar() {
  return (
    <aside className="w-[240px] shrink-0 hidden lg:flex flex-col" style={{ background: "#101B2D" }}>
      <div className="px-5 pt-5 pb-4 flex items-start gap-2.5 border-b" style={{ borderColor: "#223045" }}>
        <div className="w-8 h-8 rounded flex items-center justify-center shrink-0 mt-0.5" style={{ background: "#2E6F95" }}>
          <CloudRain size={16} color="white" strokeWidth={1.8} />
        </div>
        <div>
          <div className="text-[13.5px] font-medium text-white leading-tight">Panchayat Weather<br />Intelligence System</div>
          <div className="text-[10.5px] text-[#7E8CA3] mt-1 leading-tight">AI-powered Panchayat-level weather downscaling</div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-3 overflow-y-auto">
        {NAV.map((item) => (
          <NavLink
            key={item.label}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              "flex items-center gap-2.5 px-2.5 py-2 rounded-sm mb-0.5 transition-colors " +
              (isActive ? "" : "hover:bg-[#17233A]")
            }
            style={({ isActive }) => ({ background: isActive ? "#1E3A5C" : "transparent" })}
          >
            {({ isActive }) => (
              <>
                <item.icon size={15} color={isActive ? "#8FB4C9" : "#7E8CA3"} strokeWidth={1.8} />
                <span className="text-[12.5px]" style={{ color: isActive ? "white" : "#AEB8C7" }}>{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="px-4 pb-4">
        <div className="rounded-sm p-3 mb-3" style={{ background: "#17233A" }}>
          <div className="text-[11.5px] font-medium text-[#C7D6E8] mb-1">About This System</div>
          <div className="text-[10.5px] text-[#7E8CA3] leading-snug mb-2">AI-powered downscaling from Block-level to Panchayat-level for better agricultural decisions.</div>
          <button className="text-[10.5px] text-[#8FB4C9] flex items-center gap-1">Learn more <ChevronRight size={11} /></button>
        </div>
        <div className="rounded-sm p-3" style={{ background: "#2E210F", border: "1px solid #6B4E23" }}>
          <div className="text-[10.5px] text-[#E4C88C] leading-snug">All data shown here is simulated for demonstration purposes only and should not be used for real-world decisions.</div>
        </div>
      </div>
    </aside>
  );
}
