import React from "react";
import { RefreshCw } from "lucide-react";
import { BLOCK, PANCHAYATS } from "../data.js";
import { useSelection } from "../SelectionContext.jsx";

export default function LocationBar({ panchayatAll = false, extra = null }) {
  const { selectedId, setSelectedId } = useSelection();
  return (
    <div className="bg-white border border-[#E4E2D6] rounded-sm p-4 flex flex-wrap items-end gap-4">
      <div>
        <div className="text-[11px] text-[#8A93A0] mb-1">District</div>
        <div className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[150px] text-[#1C2430]">{BLOCK.district}</div>
      </div>
      <div>
        <div className="text-[11px] text-[#8A93A0] mb-1">Block</div>
        <div className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[150px] text-[#1C2430]">{BLOCK.block}</div>
      </div>
      <div>
        <div className="text-[11px] text-[#8A93A0] mb-1">Panchayat</div>
        <select
          value={panchayatAll ? "__all__" : selectedId}
          onChange={(e) => { if (e.target.value !== "__all__") setSelectedId(e.target.value); }}
          className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[150px] text-[#1C2430] bg-white"
        >
          {panchayatAll && <option value="__all__">All Panchayats</option>}
          {PANCHAYATS.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>
      {extra}
      <button className="ml-auto flex items-center gap-1.5 text-[12.5px] px-3 py-1.5 rounded-sm border" style={{ borderColor: "#2E6F95", color: "#2E6F95" }}>
        <RefreshCw size={13} /> Refresh Data
      </button>
    </div>
  );
}
