import React, { useState } from "react";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from "recharts";
import { Download } from "lucide-react";
import PageShell, { Card } from "../components/PageShell.jsx";
import { useSelection } from "../SelectionContext.jsx";
import { PANCHAYATS, TREND, TEMP_TREND, HUMIDITY_TREND, CONFIDENCE_TREND } from "../data.js";

const RANGES = ["Last 7 Days", "Last 14 Days", "Last 30 Days"];

export default function ChartsTrends() {
  const { selectedId, setSelectedId } = useSelection();
  const [range, setRange] = useState("Last 7 Days");
  const selected = PANCHAYATS.find((p) => p.id === selectedId) || PANCHAYATS[0];
  const trend = TREND[selected.id];

  return (
    <PageShell title="Charts & Trends" subtitle="Visual comparison and historical trends">
      <Card className="flex flex-wrap items-end gap-4">
        <div>
          <div className="text-[11px] text-[#8A93A0] mb-1">Panchayat</div>
          <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)}
            className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[170px] text-[#1C2430] bg-white">
            {PANCHAYATS.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        <div>
          <div className="text-[11px] text-[#8A93A0] mb-1">Date Range</div>
          <select value={range} onChange={(e) => setRange(e.target.value)}
            className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[150px] text-[#1C2430] bg-white">
            {RANGES.map((r) => <option key={r}>{r}</option>)}
          </select>
        </div>
        <button className="ml-auto flex items-center gap-1.5 text-[12.5px] px-3 py-1.5 rounded-sm border" style={{ borderColor: "#2E6F95", color: "#2E6F95" }}>
          <Download size={13} /> Download
        </button>
      </Card>

      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-6">
          <div className="text-[12.5px] text-[#1C2430] mb-2">Block vs Panchayat Rainfall (mm)</div>
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={trend} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
              <YAxis tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 10.5 }} />
              <Bar dataKey="block" name="Block Forecast" fill="#2E6F95" radius={[2, 2, 0, 0]} />
              <Bar dataKey="p" name="Panchayat Prediction" fill="#43714B" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="col-span-12 lg:col-span-6">
          <div className="text-[12.5px] text-[#1C2430] mb-2">Temperature Trend (°C)</div>
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={TEMP_TREND} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
              <YAxis tick={{ fontSize: 10.5, fill: "#8A93A0" }} domain={[24, 32]} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 10.5 }} />
              <Line type="monotone" dataKey="block" name="Block Forecast" stroke="#A6483A" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="p" name="Panchayat Prediction" stroke="#C08A3E" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="col-span-12 lg:col-span-6">
          <div className="text-[12.5px] text-[#1C2430] mb-2">Humidity Trend (%)</div>
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={HUMIDITY_TREND} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
              <YAxis tick={{ fontSize: 10.5, fill: "#8A93A0" }} domain={[50, 95]} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 10.5 }} />
              <Line type="monotone" dataKey="block" name="Block Forecast" stroke="#2E6F95" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="p" name="Panchayat Prediction" stroke="#6D5BA6" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="col-span-12 lg:col-span-6">
          <div className="text-[12.5px] text-[#1C2430] mb-2">Confidence Trend (%)</div>
          <ResponsiveContainer width="100%" height={230}>
            <LineChart data={CONFIDENCE_TREND} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
              <YAxis tick={{ fontSize: 10.5, fill: "#8A93A0" }} domain={[0, 100]} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 10.5 }} />
              <Line type="monotone" dataKey="confidence" name="Confidence (%)" stroke="#6D5BA6" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </PageShell>
  );
}
