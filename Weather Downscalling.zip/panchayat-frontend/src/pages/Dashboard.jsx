import React, { useState } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend
} from "recharts";
import {
  CloudRain, Map as MapIcon, Sprout, Database, History as HistoryIcon,
  ChevronRight, ChevronDown, Thermometer, Droplets, Wind, Gauge,
  AlertTriangle, CheckCircle2, RadioTower, SlidersHorizontal, Plus, Minus,
  X, Info, Cpu
} from "lucide-react";
import PageShell, { Card } from "../components/PageShell.jsx";
import { useSelection } from "../SelectionContext.jsx";
import {
  BLOCK, PANCHAYATS, TREND, TEMP_TREND, CONFIDENCE_TREND, CROPS,
  BASELINE_METRICS, AI_METRICS, rainfallColor, riskOf, confidenceTier,
  buildAdvisory, makeBlobPath,
} from "../data.js";

const DATA_SOURCES = [
  { icon: CloudRain, label: "IMD Block Forecast" },
  { icon: Database, label: "Satellite Data (Cloud & Rain)" },
  { icon: MapIcon, label: "DEM & Terrain Data" },
  { icon: HistoryIcon, label: "Historical Weather Data" },
  { icon: Sprout, label: "Land Use / Land Cover" },
  { icon: MapIcon, label: "Panchayat Boundaries" },
];

function MetricRow({ icon: Icon, label, value, unit, tone }) {
  return (
    <div className="flex flex-col items-center gap-1.5">
      <Icon size={17} style={{ color: tone || "#5B6472" }} strokeWidth={1.7} />
      <span className="text-[10.5px] text-[#8A93A0]">{label}</span>
      <span className="font-mono text-[14px] text-[#1C2430]">{value}<span className="text-[#8A93A0] text-[10.5px]">{unit}</span></span>
    </div>
  );
}

function ConfidenceGauge({ value }) {
  const r = 46, c = 2 * Math.PI * r;
  const pct = value / 100;
  return (
    <svg width="120" height="120" viewBox="0 0 120 120">
      <circle cx="60" cy="60" r={r} fill="none" stroke="#EDEBE0" strokeWidth="10" />
      <circle
        cx="60" cy="60" r={r} fill="none" stroke="#6D5BA6" strokeWidth="10"
        strokeDasharray={`${c * pct} ${c}`} strokeLinecap="round"
        transform="rotate(-90 60 60)"
      />
      <text x="60" y="56" textAnchor="middle" fontSize="20" fontFamily="IBM Plex Mono" fill="#1C2430" fontWeight="500">{value}%</text>
      <text x="60" y="72" textAnchor="middle" fontSize="9" fontFamily="IBM Plex Sans" fill="#8A93A0">Confidence</text>
    </svg>
  );
}

const TABS = ["Overview", "Weather", "History", "Advisory", "Risk"];

function Row({ label, value, valueNode }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[#8A93A0]">{label}</span>
      {valueNode || <span className="font-mono text-[#1C2430]">{value}</span>}
    </div>
  );
}

export default function Dashboard() {
  const { selectedId, setSelectedId, crop, setCrop, stage, setStage } = useSelection();
  const [panelOpen, setPanelOpen] = useState(true);
  const [tab, setTab] = useState("Overview");
  const [scenario, setScenario] = useState(1);

  const selected = PANCHAYATS.find((p) => p.id === selectedId) || PANCHAYATS[0];
  const risk = riskOf(selected);
  const range = Math.max(3, Math.round(selected.rainfall * (1 - selected.confidence / 100) * 1.5));
  const advisory = buildAdvisory(selected, crop, stage);
  const scenarioRainfall = Math.round(selected.rainfall * scenario);
  const scenarioAdvisory = buildAdvisory({ ...selected, rainfall: scenarioRainfall }, crop, stage);
  const lowConfidence = PANCHAYATS.filter((p) => p.confidence < 70);

  return (
    <PageShell title="Dashboard" subtitle="AI-powered Panchayat-level weather downscaling">
      {/* selectors */}
      <Card className="flex flex-wrap items-end gap-4">
        <div>
          <div className="text-[11px] text-[#8A93A0] mb-1">District</div>
          <div className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[170px] text-[#1C2430]">{BLOCK.district}</div>
        </div>
        <div>
          <div className="text-[11px] text-[#8A93A0] mb-1">Block</div>
          <div className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[170px] text-[#1C2430]">{BLOCK.block}</div>
        </div>
        <div>
          <div className="text-[11px] text-[#8A93A0] mb-1">Panchayat</div>
          <select value={selectedId} onChange={(e) => { setSelectedId(e.target.value); setPanelOpen(true); }}
            className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 min-w-[170px] text-[#1C2430] bg-white">
            {PANCHAYATS.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        <button className="ml-auto flex items-center gap-1.5 text-[12.5px] px-3 py-1.5 rounded-sm border" style={{ borderColor: "#2E6F95", color: "#2E6F95" }}>
          Refresh Data
        </button>
      </Card>

      {/* three top cards */}
      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-5 border-l-4" style={{ borderLeftColor: "#2E6F95" }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[13px] font-medium" style={{ color: "#2E6F95" }}>Block-level Forecast ({BLOCK.block})</span>
            <span className="text-[10.5px] px-2 py-0.5 rounded-full bg-[#EAF1F5] text-[#2E6F95]">Next 24 Hours</span>
          </div>
          <div className="grid grid-cols-5 gap-2">
            <MetricRow icon={CloudRain} label="Rainfall" value={BLOCK.rainfall.toFixed(1)} unit=" mm" tone="#2E6F95" />
            <MetricRow icon={Thermometer} label="Temp." value={BLOCK.temp} unit="°C" />
            <MetricRow icon={Droplets} label="Humidity" value={BLOCK.humidity} unit="%" />
            <MetricRow icon={Wind} label="Wind" value={BLOCK.wind} unit=" km/h" />
            <MetricRow icon={Gauge} label="Rain Prob." value={BLOCK.rainProb} unit="%" />
          </div>
          <div className="text-[10.5px] text-[#9AA2AC] mt-3 pt-2 border-t border-[#EDEBE0]">Source: IMD Block Forecast (Simulated)</div>
        </Card>

        <Card className="col-span-12 lg:col-span-5 border-l-4" style={{ borderLeftColor: "#43714B" }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-[13px] font-medium" style={{ color: "#43714B" }}>Panchayat-level Prediction ({selected.name})</span>
            <span className="text-[10.5px] px-2 py-0.5 rounded-full bg-[#EAF3EC] text-[#43714B]">Next 24 Hours</span>
          </div>
          <div className="grid grid-cols-5 gap-2">
            <MetricRow icon={CloudRain} label="Rainfall" value={selected.rainfall.toFixed(1)} unit=" mm" tone="#43714B" />
            <MetricRow icon={Thermometer} label="Temp." value={selected.temp} unit="°C" />
            <MetricRow icon={Droplets} label="Humidity" value={selected.humidity} unit="%" />
            <MetricRow icon={Wind} label="Wind" value={selected.wind} unit=" km/h" />
            <MetricRow icon={Gauge} label="Rain Prob." value={selected.rainProb} unit="%" />
          </div>
          <div className="text-[10.5px] text-[#9AA2AC] mt-3 pt-2 border-t border-[#EDEBE0] flex items-center gap-1">
            Downscaled using AI Model (XGBoost) <Cpu size={11} />
          </div>
        </Card>

        <Card className="col-span-12 lg:col-span-2 flex flex-col items-center">
          <span className="text-[12px] font-medium text-[#6D5BA6] mb-1 self-start">Model Confidence</span>
          <ConfidenceGauge value={selected.confidence} />
          <div className="text-[10px] text-[#8A93A0] text-center mt-1">Range {selected.rainfall - range}–{selected.rainfall + range} mm<br />Uncertainty ±{range} mm</div>
        </Card>
      </div>

      {/* map + detail panel */}
      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-8 relative">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <span className="text-[13px] font-medium text-[#1C2430]">Panchayat-wise Predicted Rainfall (Next 24 Hours)</span>
              <Info size={12} color="#8A93A0" />
            </div>
            <span className="text-[12px] border border-[#DEDCD1] rounded-sm px-2.5 py-1 text-[#5B6472]">Rainfall (mm)</span>
          </div>

          <div className="relative rounded-sm overflow-hidden" style={{ background: "#EAF0E7" }}>
            <div className="absolute top-3 left-3 z-10 bg-white/95 border border-[#DEDCD1] rounded-sm px-3 py-2 text-[10.5px]">
              <div className="text-[#5B6472] mb-1.5">Rainfall (mm)</div>
              {[["#123A54", "> 60 mm"], ["#1B587F", "45 – 60 mm"], ["#2E6F95", "30 – 45 mm"], ["#6FA3BE", "15 – 30 mm"], ["#C3DBE5", "< 15 mm"]].map(([c, l]) => (
                <div key={l} className="flex items-center gap-1.5 py-0.5">
                  <span className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: c }} />
                  <span className="text-[#5B6472]">{l}</span>
                </div>
              ))}
            </div>
            <div className="absolute bottom-3 left-3 z-10 flex flex-col bg-white border border-[#DEDCD1] rounded-sm overflow-hidden">
              <button className="w-7 h-7 flex items-center justify-center border-b border-[#DEDCD1]"><Plus size={13} color="#5B6472" /></button>
              <button className="w-7 h-7 flex items-center justify-center"><Minus size={13} color="#5B6472" /></button>
            </div>
            <div className="absolute bottom-3 left-14 z-10 text-[10px] text-[#5B6472] bg-white/90 px-1.5 rounded-sm">5 km</div>
            <div className="absolute bottom-2 right-3 z-10 text-[9.5px] text-[#7A8390]">Schematic demo layout — see Map View for the geographic map</div>

            <svg viewBox="0 0 760 480" className="w-full h-auto">
              {PANCHAYATS.map((p) => {
                const base = 42 + Math.min(p.rainfall, 60) / 60 * 14;
                return (
                  <g key={p.id} onClick={() => { setSelectedId(p.id); setPanelOpen(true); }} className="cursor-pointer">
                    <path
                      d={makeBlobPath(p.cx, p.cy, base, p.seed)}
                      fill={rainfallColor(p.rainfall)}
                      stroke={p.id === selectedId ? "#1C2430" : "white"}
                      strokeWidth={p.id === selectedId ? 3 : 1.6}
                      opacity={p.id === selectedId ? 1 : 0.9}
                    />
                    <text x={p.cx} y={p.cy - 6} textAnchor="middle" fontSize="11" fill="white" fontFamily="IBM Plex Sans, sans-serif" fontWeight="500">{p.name}</text>
                    <text x={p.cx} y={p.cy + 11} textAnchor="middle" fontSize="12" fill="white" fontFamily="IBM Plex Mono, monospace">{p.rainfall} mm</text>
                    {p.id === selectedId && <circle cx={p.cx} cy={p.cy + 26} r="4" fill="#101B2D" stroke="white" strokeWidth="1.5" />}
                  </g>
                );
              })}
            </svg>
          </div>
        </Card>

        {/* detail panel */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-4">
          {panelOpen ? (
            <Card>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[12px] text-[#8A93A0]">Panchayat Details</span>
                <button onClick={() => setPanelOpen(false)}><X size={14} color="#8A93A0" /></button>
              </div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[15px] text-[#1C2430]">{selected.name} <span className="text-[11px] text-[#8A93A0]">(Demo Panchayat)</span></span>
                <span className="text-[10.5px] px-2 py-0.5 rounded-full" style={{ background: risk.bg, color: risk.color }}>{risk.label}</span>
              </div>

              <div className="flex gap-3 mb-3 border-b border-[#EDEBE0] text-[11.5px]">
                {TABS.map((t) => (
                  <button key={t} onClick={() => setTab(t)}
                    className="pb-2 -mb-px"
                    style={{ color: tab === t ? "#2E6F95" : "#8A93A0", borderBottom: tab === t ? "2px solid #2E6F95" : "2px solid transparent" }}>{t}</button>
                ))}
              </div>

              {tab === "Overview" && (
                <div className="space-y-2 text-[12.5px]">
                  <Row label="Predicted Rainfall (24H)" value={`${selected.rainfall.toFixed(1)} mm`} />
                  <Row label="Expected Range" value={`${selected.rainfall - range}–${selected.rainfall + range} mm`} />
                  <Row label="Confidence" value={`${selected.confidence}%`} />
                  <Row label="Rain Probability" value={`${selected.rainProb}%`} />
                  <Row label="Risk Level" valueNode={<span style={{ color: risk.color }}>{risk.label}</span>} />
                  <button onClick={() => setTab("Advisory")} className="text-[11.5px] text-[#2E6F95] flex items-center gap-1 pt-1">View Full Advisory <ChevronRight size={12} /></button>
                </div>
              )}

              {tab === "Weather" && (
                <div className="space-y-2 text-[12.5px]">
                  <Row label="Temperature" value={`${selected.temp} °C`} />
                  <Row label="Humidity" value={`${selected.humidity}%`} />
                  <Row label="Wind" value={`${selected.wind} km/h`} />
                  <Row label="Elevation" value={`${selected.elevation} m`} />
                  <Row label="Terrain" value={selected.terrain} />
                  <div className="text-[10.5px] text-[#9AA2AC] pt-1">Block reference: {BLOCK.rainfall}mm · {BLOCK.temp}°C · {BLOCK.humidity}%</div>
                </div>
              )}

              {tab === "History" && (
                <div>
                  <Row label="Historical Average" value={`${selected.historicalAvg} mm`} />
                  <ResponsiveContainer width="100%" height={110}>
                    <LineChart data={TREND[selected.id]} margin={{ top: 8, right: 5, left: -25, bottom: 0 }}>
                      <XAxis dataKey="d" tick={{ fontSize: 9, fill: "#8A93A0" }} />
                      <YAxis tick={{ fontSize: 9, fill: "#8A93A0" }} />
                      <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
                      <Line type="monotone" dataKey="p" name="Predicted" stroke="#43714B" strokeWidth={2} dot={{ r: 2 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}

              {tab === "Advisory" && (
                <div>
                  <div className="flex gap-2 mb-2">
                    <select value={crop} onChange={(e) => setCrop(e.target.value)}
                      className="flex-1 text-[12px] border border-[#DEDCD1] rounded-sm px-2 py-1 bg-white text-[#1C2430]">
                      {Object.keys(CROPS).map((c) => <option key={c}>{c}</option>)}
                    </select>
                    <select value={stage} onChange={(e) => setStage(e.target.value)}
                      className="flex-1 text-[12px] border border-[#DEDCD1] rounded-sm px-2 py-1 bg-white text-[#1C2430]">
                      {CROPS[crop].map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                  <div className="rounded-sm p-2.5 mb-2" style={{
                    background: advisory.severity === "high" ? "#A6483A0F" : "#43714B0F",
                    border: `1px solid ${advisory.severity === "high" ? "#A6483A33" : "#43714B33"}`,
                  }}>
                    <div className="flex items-center gap-1.5 mb-1">
                      {advisory.severity === "high" ? <AlertTriangle size={13} color="#A6483A" /> : <CheckCircle2 size={13} color="#43714B" />}
                      <span className="text-[11.5px]" style={{ color: advisory.severity === "high" ? "#A6483A" : "#43714B" }}>
                        {advisory.severity === "high" ? "Attention needed" : "Favorable conditions"}
                      </span>
                    </div>
                    {advisory.notes.map((n, i) => <div key={i} className="text-[11.5px] text-[#3B4451] leading-snug">· {n}</div>)}
                  </div>
                  <div className="border-t border-[#EDEBE0] pt-2">
                    <div className="flex items-center gap-1.5 mb-1.5 text-[10.5px] text-[#8A93A0]"><SlidersHorizontal size={11} /> What-if scenario (simulation)</div>
                    <div className="flex gap-1.5 mb-1.5">
                      {[{ l: "Normal", v: 1 }, { l: "Moderate", v: 1.4 }, { l: "Extreme", v: 2 }].map((s) => (
                        <button key={s.l} onClick={() => setScenario(s.v)} className="px-2 py-0.5 rounded-sm text-[10.5px]"
                          style={{ background: scenario === s.v ? "#101B2D" : "#F1F2ED", color: scenario === s.v ? "white" : "#5B6472" }}>{s.l}</button>
                      ))}
                    </div>
                    <div className="text-[11.5px]">{scenarioRainfall} mm → <span style={{ color: scenarioAdvisory.severity === "high" ? "#A6483A" : "#43714B" }}>{scenarioAdvisory.severity === "high" ? "Elevated risk" : "Normal risk"}</span></div>
                  </div>
                </div>
              )}

              {tab === "Risk" && (
                <div className="space-y-2 text-[12.5px]">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-[10.5px] px-2 py-0.5 rounded-full" style={{ background: risk.bg, color: risk.color }}>{risk.label}</span>
                  </div>
                  <div className="text-[11.5px] text-[#3B4451]">· Rainfall {selected.rainfall}mm {selected.rainfall > 50 ? "(above heavy-rain threshold)" : selected.rainfall < 15 ? "(below dry threshold)" : "(within normal range)"}</div>
                  <div className="text-[11.5px] text-[#3B4451]">· Confidence {selected.confidence}% ({confidenceTier(selected.confidence).label.toLowerCase()})</div>
                  <div className="text-[11.5px] text-[#3B4451]">· {selected.confidence < 70 ? "Sparse nearby observations reduce certainty" : "Adequate nearby observation coverage"}</div>
                </div>
              )}
            </Card>
          ) : (
            <button onClick={() => setPanelOpen(true)} className="bg-white border border-[#E4E2D6] rounded-sm p-3 text-[12px] text-[#2E6F95]">Show Panchayat Details →</button>
          )}

          <Card>
            <div className="text-[12.5px] text-[#1C2430] mb-2">Data Sources <span className="text-[10.5px] text-[#8A93A0]">(Simulated)</span></div>
            {DATA_SOURCES.map((s) => (
              <div key={s.label} className="flex items-center gap-2 py-1 border-t border-[#EDEBE0] first:border-t-0">
                <s.icon size={13} color="#8A93A0" strokeWidth={1.8} />
                <span className="text-[12px] text-[#3B4451] flex-1">{s.label}</span>
                <span className="text-[9.5px] px-1.5 py-0.5 rounded-full bg-[#EAF3EC] text-[#43714B]">Simulated</span>
              </div>
            ))}
          </Card>

          {lowConfidence.length > 0 && (
            <Card>
              <div className="flex items-center gap-1.5 mb-2">
                <RadioTower size={13} color="#A6483A" />
                <span className="text-[12.5px] text-[#1C2430]">Observation Gap</span>
              </div>
              {lowConfidence.map((p) => (
                <div key={p.id} className="text-[11.5px] text-[#5B6472] py-1 border-t border-[#EDEBE0] first:border-t-0">
                  <span className="text-[#293240]">{p.name}</span> — {p.confidence}% confidence, additional station recommended.
                </div>
              ))}
            </Card>
          )}
        </div>
      </div>

      {/* bottom trend charts */}
      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-4">
          <div className="text-[12.5px] text-[#1C2430] mb-2">Block vs Panchayat Rainfall (Next 7 Days)</div>
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={TREND[selected.id]} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 10, fill: "#8A93A0" }} />
              <YAxis tick={{ fontSize: 10, fill: "#8A93A0" }} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 10.5 }} />
              <Line type="monotone" dataKey="block" name="Block Forecast" stroke="#2E6F95" strokeWidth={2} dot={{ r: 2.5 }} />
              <Line type="monotone" dataKey="p" name="Panchayat Prediction" stroke="#43714B" strokeWidth={2} dot={{ r: 2.5 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
        <Card className="col-span-12 lg:col-span-4">
          <div className="text-[12.5px] text-[#1C2430] mb-2">Temperature Trend (Next 7 Days)</div>
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={TEMP_TREND} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 10, fill: "#8A93A0" }} />
              <YAxis tick={{ fontSize: 10, fill: "#8A93A0" }} domain={[24, 32]} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 10.5 }} />
              <Line type="monotone" dataKey="block" name="Block Forecast (°C)" stroke="#A6483A" strokeWidth={2} dot={{ r: 2.5 }} />
              <Line type="monotone" dataKey="p" name="Panchayat Prediction (°C)" stroke="#C08A3E" strokeWidth={2} dot={{ r: 2.5 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
        <Card className="col-span-12 lg:col-span-4">
          <div className="text-[12.5px] text-[#1C2430] mb-2">Model Confidence Trend (Next 7 Days)</div>
          <ResponsiveContainer width="100%" height={190}>
            <LineChart data={CONFIDENCE_TREND} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 10, fill: "#8A93A0" }} />
              <YAxis tick={{ fontSize: 10, fill: "#8A93A0" }} domain={[0, 100]} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
              <Legend wrapperStyle={{ fontSize: 10.5 }} />
              <Line type="monotone" dataKey="confidence" name="Confidence (%)" stroke="#6D5BA6" strokeWidth={2} dot={{ r: 2.5 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* model evaluation strip */}
      <Card className="flex flex-wrap items-center gap-6">
        <span className="text-[12.5px] text-[#1C2430]">Model Evaluation (vs. baseline = Block value applied to every panchayat)</span>
        <div className="flex items-center gap-4 text-[12px] font-mono">
          <span className="text-[#A6483A]">Baseline — MAE {BASELINE_METRICS.mae}, RMSE {BASELINE_METRICS.rmse}, R² {BASELINE_METRICS.r2}</span>
          <span className="text-[#43714B]">AI Model — MAE {AI_METRICS.mae}, RMSE {AI_METRICS.rmse}, R² {AI_METRICS.r2}</span>
        </div>
        <span className="text-[10.5px] text-[#9AA2AC] ml-auto">Illustrative demo figures — replace with real backtest results.</span>
      </Card>
    </PageShell>
  );
}
