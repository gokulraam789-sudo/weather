import React, { useState } from "react";
import { BookOpen, LifeBuoy, Info, ChevronRight } from "lucide-react";
import PageShell, { Card } from "../components/PageShell.jsx";
import { DISTRICT } from "../data.js";

function Toggle({ checked, onChange }) {
  return (
    <button onClick={() => onChange(!checked)} className="w-9 h-5 rounded-full relative transition-colors shrink-0"
      style={{ background: checked ? "#2E6F95" : "#D9D6C9" }}>
      <span className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all" style={{ left: checked ? 18 : 2 }} />
    </button>
  );
}

function Field({ label, value }) {
  return (
    <div className="mb-3">
      <div className="text-[11px] text-[#8A93A0] mb-1">{label}</div>
      <div className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 text-[#1C2430] bg-white">{value}</div>
    </div>
  );
}

export default function Settings() {
  const [notif, setNotif] = useState(true);
  const [demoData, setDemoData] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  return (
    <PageShell title="Settings" subtitle="Configure your application">
      <div className="flex gap-2 border-b border-[#E4E2D6]">
        <button className="px-3 py-2 text-[12.5px] -mb-px border-b-2" style={{ color: "#2E6F95", borderColor: "#2E6F95" }}>Profile</button>
        <button className="px-3 py-2 text-[12.5px] text-[#8A93A0] -mb-px border-b-2 border-transparent">System</button>
      </div>

      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-5">
          <div className="text-[13px] font-medium text-[#1C2430] mb-3">User Profile</div>
          <Field label="Name" value="Demo User" />
          <Field label="Role" value="Agriculture Officer" />
          <Field label="Email" value="demo@panchayatweather.in" />
          <Field label="District" value={DISTRICT} />
          <button className="mt-1 text-[12.5px] px-3 py-1.5 rounded-sm text-white" style={{ background: "#101B2D" }}>
            Update Profile
          </button>
        </Card>

        <Card className="col-span-12 lg:col-span-7">
          <div className="text-[13px] font-medium text-[#1C2430] mb-3">System Settings</div>
          <div className="flex items-center justify-between py-2 border-t border-[#EDEBE0] first:border-t-0">
            <span className="text-[12.5px] text-[#3B4451]">Data Refresh Interval</span>
            <select className="text-[12px] border border-[#DEDCD1] rounded-sm px-2 py-1 bg-white text-[#1C2430]">
              <option>15 minutes</option><option>1 hour</option><option>6 hours</option>
            </select>
          </div>
          <div className="flex items-center justify-between py-2 border-t border-[#EDEBE0]">
            <span className="text-[12.5px] text-[#3B4451]">Show Demo Data</span>
            <Toggle checked={demoData} onChange={setDemoData} />
          </div>
          <div className="flex items-center justify-between py-2 border-t border-[#EDEBE0]">
            <span className="text-[12.5px] text-[#3B4451]">Enable Notifications</span>
            <Toggle checked={notif} onChange={setNotif} />
          </div>
          <div className="flex items-center justify-between py-2 border-t border-[#EDEBE0]">
            <span className="text-[12.5px] text-[#3B4451]">Dark Mode</span>
            <Toggle checked={darkMode} onChange={setDarkMode} />
          </div>
          <div className="flex items-center justify-between py-2 border-t border-[#EDEBE0]">
            <span className="text-[12.5px] text-[#3B4451]">Data Privacy</span>
            <a href="#" className="text-[11.5px] text-[#2E6F95]">View Policy</a>
          </div>
          <div className="flex items-center justify-between py-2 border-t border-[#EDEBE0]">
            <span className="text-[12.5px] text-[#3B4451]">Language</span>
            <select className="text-[12px] border border-[#DEDCD1] rounded-sm px-2 py-1 bg-white text-[#1C2430]">
              <option>English</option><option>Tamil</option><option>Hindi</option>
            </select>
          </div>
        </Card>
      </div>

      <Card>
        <div className="text-[13px] font-medium text-[#1C2430] mb-3">Help & Support</div>
        {[
          { icon: BookOpen, label: "User Guide" },
          { icon: LifeBuoy, label: "Contact Support" },
          { icon: Info, label: "About the System" },
        ].map((s) => (
          <button key={s.label} className="w-full flex items-center gap-2.5 py-2.5 border-t border-[#EDEBE0] first:border-t-0 text-left">
            <s.icon size={15} color="#5B6472" />
            <span className="text-[12.5px] text-[#3B4451] flex-1">{s.label}</span>
            <ChevronRight size={14} color="#9AA2AC" />
          </button>
        ))}
      </Card>
    </PageShell>
  );
}
