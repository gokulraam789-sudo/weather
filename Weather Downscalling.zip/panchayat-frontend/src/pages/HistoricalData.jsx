import React, { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import PageShell, { Card } from "../components/PageShell.jsx";
import LocationBar from "../components/LocationBar.jsx";
import { HISTORICAL_RECORDS, HISTORICAL_COMPARISON, AVG_TEMP_COMPARISON } from "../data.js";

const TABS = ["Weather Data", "Crop Data", "Comparison"];

export default function HistoricalData() {
  const [tab, setTab] = useState("Weather Data");

  return (
    <PageShell title="Historical Data" subtitle="Past weather data and comparison">
      <LocationBar
        extra={
          <div>
            <div className="text-[11px] text-[#8A93A0] mb-1">Date Range</div>
            <div className="text-[13px] border border-[#DEDCD1] rounded-sm px-3 py-1.5 text-[#1C2430]">Apr 28, 2026 – May 4, 2026</div>
          </div>
        }
      />

      <div className="flex gap-2 border-b border-[#E4E2D6]">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className="px-3 py-2 text-[12.5px] -mb-px"
            style={{ color: tab === t ? "#2E6F95" : "#8A93A0", borderBottom: tab === t ? "2px solid #2E6F95" : "2px solid transparent" }}>{t}</button>
        ))}
      </div>

      {tab === "Weather Data" && (
        <Card className="p-0 overflow-hidden">
          <table className="w-full text-[12.5px]">
            <thead>
              <tr className="text-left text-[#8A93A0] border-b border-[#EDEBE0]">
                <th className="py-2.5 px-4 font-normal">Date</th>
                <th className="py-2.5 px-4 font-normal">Rainfall (mm)</th>
                <th className="py-2.5 px-4 font-normal">Temp. (°C)</th>
                <th className="py-2.5 px-4 font-normal">Humidity (%)</th>
                <th className="py-2.5 px-4 font-normal">Wind (km/h)</th>
                <th className="py-2.5 px-4 font-normal">Rain Prob. (%)</th>
              </tr>
            </thead>
            <tbody>
              {HISTORICAL_RECORDS.map((r) => (
                <tr key={r.date} className="border-b border-[#EDEBE0] last:border-b-0">
                  <td className="py-2 px-4 text-[#1C2430] font-mono">{r.date}</td>
                  <td className="py-2 px-4 text-[#1C2430] font-mono">{r.rainfall}</td>
                  <td className="py-2 px-4 text-[#1C2430] font-mono">{r.temp}</td>
                  <td className="py-2 px-4 text-[#1C2430] font-mono">{r.humidity}</td>
                  <td className="py-2 px-4 text-[#1C2430] font-mono">{r.wind}</td>
                  <td className="py-2 px-4 text-[#1C2430] font-mono">{r.rainProb}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {tab === "Crop Data" && (
        <Card>
          <div className="text-[12.5px] text-[#1C2430] mb-3">Historical Crop Calendar (Demo)</div>
          <div className="text-[12px] text-[#5B6472] leading-relaxed">
            Crop-stage-wise historical yield and sowing/harvest data will be sourced from data.gov.in and state
            agriculture department records. This section is a placeholder in the current prototype — the
            production version will show sowing dates, historical yield per hectare, and stage-wise weather
            sensitivity for each supported crop in this Panchayat.
          </div>
        </Card>
      )}

      {tab === "Comparison" && (
        <div className="grid grid-cols-12 gap-5">
          <Card className="col-span-12 lg:col-span-8">
            <div className="text-[12.5px] text-[#1C2430] mb-2">Rainfall Comparison — Forecast vs This Period vs Last Year</div>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={HISTORICAL_COMPARISON} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
                <YAxis tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
                <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
                <Legend wrapperStyle={{ fontSize: 10.5 }} />
                <Bar dataKey="forecast" name="Forecast" fill="#2E6F95" radius={[2, 2, 0, 0]} />
                <Bar dataKey="thisPeriod" name="This Period" fill="#43714B" radius={[2, 2, 0, 0]} />
                <Bar dataKey="lastYear" name="Last Year" fill="#C08A3E" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
          <Card className="col-span-12 lg:col-span-4">
            <div className="text-[12.5px] text-[#1C2430] mb-3">Average Temperature (°C)</div>
            <div className="flex items-center justify-between border-b border-[#EDEBE0] pb-3 mb-3">
              <span className="text-[12px] text-[#8A93A0]">This Period</span>
              <span className="text-[20px] font-mono text-[#1C2430]">{AVG_TEMP_COMPARISON.thisPeriod}°C</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[12px] text-[#8A93A0]">Last Year</span>
              <span className="text-[20px] font-mono text-[#1C2430]">{AVG_TEMP_COMPARISON.lastYear}°C</span>
            </div>
            <div className="text-[10.5px] text-[#9AA2AC] mt-4 pt-3 border-t border-[#EDEBE0]">
              This period is {(AVG_TEMP_COMPARISON.lastYear - AVG_TEMP_COMPARISON.thisPeriod).toFixed(1)}°C cooler than the same week last year (demo figures).
            </div>
          </Card>
        </div>
      )}
    </PageShell>
  );
}
