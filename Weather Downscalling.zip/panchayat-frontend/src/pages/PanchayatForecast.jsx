import React from "react";
import { CloudRain, Cloud, Sun, Thermometer, Droplets, Wind, Gauge } from "lucide-react";
import PageShell, { Card } from "../components/PageShell.jsx";
import LocationBar from "../components/LocationBar.jsx";
import { useSelection } from "../SelectionContext.jsx";
import { PANCHAYATS, SEVEN_DAY, confidenceTier } from "../data.js";

function CondIcon({ cond, size = 22, color }) {
  if (cond === "rain") return <CloudRain size={size} color={color || "#2E6F95"} strokeWidth={1.8} />;
  if (cond === "cloud") return <Cloud size={size} color={color || "#8A93A0"} strokeWidth={1.8} />;
  return <Sun size={size} color={color || "#C08A3E"} strokeWidth={1.8} />;
}

function ConfidenceRing({ value }) {
  const r = 44, c = 2 * Math.PI * r;
  const tier = confidenceTier(value);
  return (
    <svg width="112" height="112" viewBox="0 0 112 112">
      <circle cx="56" cy="56" r={r} fill="none" stroke="#EDEBE0" strokeWidth="9" />
      <circle cx="56" cy="56" r={r} fill="none" stroke={tier.color} strokeWidth="9"
        strokeDasharray={`${c * (value / 100)} ${c}`} strokeLinecap="round" transform="rotate(-90 56 56)" />
      <text x="56" y="52" textAnchor="middle" fontSize="18" fontFamily="IBM Plex Mono" fill="#1C2430" fontWeight="500">{value}%</text>
      <text x="56" y="68" textAnchor="middle" fontSize="8.5" fontFamily="IBM Plex Sans" fill="#8A93A0">{tier.label}</text>
    </svg>
  );
}

export default function PanchayatForecast() {
  const { selectedId } = useSelection();
  const selected = PANCHAYATS.find((p) => p.id === selectedId) || PANCHAYATS[0];

  return (
    <PageShell title="Panchayat Forecast" subtitle="Detailed forecast for selected Panchayat">
      <LocationBar />

      <Card>
        <div className="flex items-center justify-between mb-3">
          <span className="text-[13px] font-medium text-[#1C2430]">{selected.name} — 7 Day Forecast <span className="text-[10.5px] text-[#8A93A0]">(Simulated)</span></span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {SEVEN_DAY.map((d, i) => (
            <div key={d.date} className={"rounded-sm border p-3 flex flex-col items-center gap-1.5 " + (i === 0 ? "border-[#2E6F95]" : "border-[#E4E2D6]")} style={i === 0 ? { background: "#EAF1F5" } : {}}>
              <div className="text-[11px] text-[#5B6472]">{d.day}</div>
              <div className="text-[10px] text-[#8A93A0] font-mono">{d.date}</div>
              <CondIcon cond={d.cond} />
              <div className="text-[13px] font-mono text-[#1C2430]">{d.tempHi}°<span className="text-[#8A93A0]">/{d.tempLo}°</span></div>
              <div className="text-[11px] font-mono" style={{ color: "#2E6F95" }}>{d.rainfall} mm</div>
              <div className="text-[10px] text-[#8A93A0]">{d.rainProb}% rain</div>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-8">
          <div className="text-[13px] font-medium text-[#1C2430] mb-3">Weather Details (Current)</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { icon: CloudRain, label: "Rainfall", value: `${selected.rainfall} mm`, tone: "#2E6F95" },
              { icon: Thermometer, label: "Temperature", value: `${selected.temp}°C`, tone: "#A6483A" },
              { icon: Droplets, label: "Humidity", value: `${selected.humidity}%`, tone: "#43714B" },
              { icon: Wind, label: "Wind", value: `${selected.wind} km/h`, tone: "#6D5BA6" },
            ].map((m) => (
              <div key={m.label} className="rounded-sm border border-[#E4E2D6] p-3 flex flex-col items-center gap-1.5">
                <m.icon size={20} color={m.tone} strokeWidth={1.8} />
                <div className="text-[11px] text-[#8A93A0]">{m.label}</div>
                <div className="text-[15px] font-mono text-[#1C2430]">{m.value}</div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4 mt-4 text-[12.5px]">
            <div className="flex items-center justify-between border-t border-[#EDEBE0] pt-2">
              <span className="text-[#8A93A0]">Elevation</span><span className="font-mono text-[#1C2430]">{selected.elevation} m</span>
            </div>
            <div className="flex items-center justify-between border-t border-[#EDEBE0] pt-2">
              <span className="text-[#8A93A0]">Terrain</span><span className="text-[#1C2430]">{selected.terrain}</span>
            </div>
            <div className="flex items-center justify-between border-t border-[#EDEBE0] pt-2">
              <span className="text-[#8A93A0]">Land Cover</span><span className="text-[#1C2430]">{selected.landCover}</span>
            </div>
            <div className="flex items-center justify-between border-t border-[#EDEBE0] pt-2">
              <span className="text-[#8A93A0]">Historical Average</span><span className="font-mono text-[#1C2430]">{selected.historicalAvg} mm</span>
            </div>
          </div>
        </Card>

        <Card className="col-span-12 lg:col-span-4 flex flex-col items-center">
          <div className="text-[13px] font-medium text-[#1C2430] self-start mb-2">Confidence Score</div>
          <ConfidenceRing value={selected.confidence} />
          <div className="text-[11px] text-[#8A93A0] text-center mt-2 leading-snug">
            Based on data density, terrain complexity, and historical forecast accuracy for {selected.name}.
          </div>
          <div className="w-full flex items-center justify-between text-[11px] text-[#8A93A0] mt-3 pt-3 border-t border-[#EDEBE0]">
            <span className="flex items-center gap-1"><Gauge size={12} /> Rain Probability</span>
            <span className="font-mono text-[#1C2430]">{selected.rainProb}%</span>
          </div>
        </Card>
      </div>
    </PageShell>
  );
}
