import React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import PageShell, { Card } from "../components/PageShell.jsx";
import { MODEL_INFO, PERFORMANCE_METRICS, FEATURE_IMPORTANCE } from "../data.js";

function R2Gauge({ value }) {
  const r = 46, c = 2 * Math.PI * r;
  return (
    <svg width="116" height="116" viewBox="0 0 116 116">
      <circle cx="58" cy="58" r={r} fill="none" stroke="#EDEBE0" strokeWidth="10" />
      <circle cx="58" cy="58" r={r} fill="none" stroke="#2E6F95" strokeWidth="10"
        strokeDasharray={`${c * value} ${c}`} strokeLinecap="round" transform="rotate(-90 58 58)" />
      <text x="58" y="54" textAnchor="middle" fontSize="19" fontFamily="IBM Plex Mono" fill="#1C2430" fontWeight="500">{value.toFixed(2)}</text>
      <text x="58" y="70" textAnchor="middle" fontSize="8.5" fontFamily="IBM Plex Sans" fill="#8A93A0">R² Score</text>
    </svg>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-t border-[#EDEBE0] first:border-t-0">
      <span className="text-[12px] text-[#8A93A0]">{label}</span>
      <span className="text-[12.5px] text-[#1C2430] font-mono">{value}</span>
    </div>
  );
}

export default function ModelInfo() {
  return (
    <PageShell title="Model Info" subtitle="AI/ML model details and performance">
      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-7">
          <div className="text-[13px] font-medium text-[#1C2430] mb-2">Model Overview</div>
          <Row label="Model Name" value={MODEL_INFO.name} />
          <Row label="Training Data" value={MODEL_INFO.trainingData} />
          <Row label="Features" value={MODEL_INFO.featureDesc} />
          <Row label="Model Version" value={MODEL_INFO.version} />
          <Row label="Last Trained" value={MODEL_INFO.lastTrained} />
          <div className="text-[11px] text-[#9AA2AC] mt-3 pt-3 border-t border-[#EDEBE0] leading-relaxed">
            The model infers Panchayat-level rainfall, temperature, humidity and wind from Block-level forecasts
            combined with geographic, historical and (where available) satellite and ground-observation features.
            It is compared against a naive baseline that applies the Block forecast uniformly to every Panchayat.
          </div>
        </Card>

        <Card className="col-span-12 lg:col-span-5 flex flex-col items-center">
          <div className="text-[13px] font-medium text-[#1C2430] self-start mb-2">Performance Metrics</div>
          <R2Gauge value={PERFORMANCE_METRICS.r2} />
          <div className="grid grid-cols-3 gap-3 w-full mt-4 pt-3 border-t border-[#EDEBE0] text-center">
            <div>
              <div className="text-[10.5px] text-[#8A93A0]">MAE</div>
              <div className="text-[14px] font-mono text-[#1C2430]">{PERFORMANCE_METRICS.mae} mm</div>
            </div>
            <div>
              <div className="text-[10.5px] text-[#8A93A0]">RMSE</div>
              <div className="text-[14px] font-mono text-[#1C2430]">{PERFORMANCE_METRICS.rmse} mm</div>
            </div>
            <div>
              <div className="text-[10.5px] text-[#8A93A0]">Accuracy</div>
              <div className="text-[14px] font-mono text-[#1C2430]">{PERFORMANCE_METRICS.accuracy}%</div>
            </div>
          </div>
        </Card>
      </div>

      <Card>
        <div className="text-[13px] font-medium text-[#1C2430] mb-3">Feature Importance</div>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={FEATURE_IMPORTANCE} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="2 4" stroke="#EDEBE0" horizontal={false} />
            <XAxis type="number" domain={[0, 0.4]} tick={{ fontSize: 10.5, fill: "#8A93A0" }} />
            <YAxis type="category" dataKey="feature" width={110} tick={{ fontSize: 11, fill: "#3B4451" }} />
            <Tooltip contentStyle={{ fontSize: 11, borderRadius: 4 }} />
            <Bar dataKey="value" name="Importance" fill="#2E6F95" radius={[0, 3, 3, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <button className="mt-2 text-[12px] px-3 py-1.5 rounded-sm border" style={{ borderColor: "#2E6F95", color: "#2E6F95" }}>
          View Technical Details
        </button>
      </Card>
    </PageShell>
  );
}
