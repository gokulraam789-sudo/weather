import React, { useState } from "react";
import { MapContainer, TileLayer, CircleMarker, Popup, Tooltip as LeafletTooltip } from "react-leaflet";
import { Layers, ChevronRight } from "lucide-react";
import PageShell, { Card } from "../components/PageShell.jsx";
import LocationBar from "../components/LocationBar.jsx";
import { useSelection } from "../SelectionContext.jsx";
import { BLOCK, PANCHAYATS, rainfallColor, riskOf } from "../data.js";

const LAYER_OPTIONS = [
  { key: "boundaries", label: "Panchayat Boundaries", default: true },
  { key: "rainfall", label: "Rainfall (Predicted)", default: true },
  { key: "temperature", label: "Temperature", default: false },
  { key: "risk", label: "Risk Level", default: false },
  { key: "satellite", label: "Satellite Layer", default: false },
];

function riskColor(p) {
  const r = riskOf(p);
  if (r.label === "High Risk") return "#A6483A";
  if (r.label === "Moderate Risk") return "#C08A3E";
  return "#43714B";
}

export default function MapView() {
  const { selectedId, setSelectedId } = useSelection();
  const [layers, setLayers] = useState(
    Object.fromEntries(LAYER_OPTIONS.map((l) => [l.key, l.default]))
  );
  const [colorMode, setColorMode] = useState("rainfall"); // rainfall | risk | temperature

  const toggleLayer = (key) => {
    setLayers((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      if (key === "risk" && next.risk) setColorMode("risk");
      if (key === "temperature" && next.temperature) setColorMode("temperature");
      if (key === "rainfall" && next.rainfall) setColorMode("rainfall");
      return next;
    });
  };

  const selected = PANCHAYATS.find((p) => p.id === selectedId) || PANCHAYATS[0];

  function colorFor(p) {
    if (colorMode === "risk") return riskColor(p);
    if (colorMode === "temperature") {
      // simple warm scale 26-30C
      const t = Math.min(1, Math.max(0, (p.temp - 26) / 4));
      const c1 = [46, 111, 149], c2 = [166, 72, 58];
      const mix = c1.map((c, i) => Math.round(c + (c2[i] - c) * t));
      return `rgb(${mix.join(",")})`;
    }
    return rainfallColor(p.rainfall);
  }

  return (
    <PageShell title="Map View" subtitle="Interactive map with Panchayat boundaries and weather data">
      <LocationBar
        panchayatAll
        extra={
          <button className="flex items-center gap-1.5 text-[12.5px] px-3 py-1.5 rounded-sm border border-[#DEDCD1] text-[#5B6472]">
            <Layers size={13} /> Layers
          </button>
        }
      />

      <div className="grid grid-cols-12 gap-5">
        <Card className="col-span-12 lg:col-span-9 p-0 overflow-hidden relative">
          <div style={{ height: 560 }}>
            <MapContainer center={BLOCK.center} zoom={12} style={{ height: "100%", width: "100%" }} scrollWheelZoom>
              <TileLayer
                attribution='&copy; OpenStreetMap contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {layers.boundaries && PANCHAYATS.map((p) => {
                const isSel = p.id === selectedId;
                return (
                  <CircleMarker
                    key={p.id}
                    center={[p.lat, p.lng]}
                    radius={layers.rainfall ? 14 + Math.min(p.rainfall, 60) / 6 : 16}
                    pathOptions={{
                      color: isSel ? "#101B2D" : "white",
                      weight: isSel ? 3 : 1.5,
                      fillColor: colorFor(p),
                      fillOpacity: 0.85,
                    }}
                    eventHandlers={{ click: () => setSelectedId(p.id) }}
                  >
                    <LeafletTooltip direction="top" offset={[0, -6]} opacity={1} permanent={false}>
                      {p.name} — {p.rainfall} mm
                    </LeafletTooltip>
                    <Popup>
                      <div style={{ fontFamily: "IBM Plex Sans, sans-serif", fontSize: 12.5, minWidth: 160 }}>
                        <div style={{ fontWeight: 600, marginBottom: 4, color: "#1C2430" }}>{p.name}</div>
                        <div style={{ color: "#5B6472" }}>Predicted Rainfall: <b style={{ color: "#1C2430" }}>{p.rainfall} mm</b></div>
                        <div style={{ color: "#5B6472" }}>Temp: <b style={{ color: "#1C2430" }}>{p.temp}°C</b> · Humidity: <b style={{ color: "#1C2430" }}>{p.humidity}%</b></div>
                        <div style={{ color: "#5B6472" }}>Confidence: <b style={{ color: "#1C2430" }}>{p.confidence}%</b></div>
                        <div style={{ color: "#5B6472", marginBottom: 6 }}>Risk: <b style={{ color: riskColor(p) }}>{riskOf(p).label.replace(" Risk", "")}</b></div>
                        <button
                          onClick={() => setSelectedId(p.id)}
                          style={{ background: "#101B2D", color: "white", border: "none", borderRadius: 3, padding: "4px 10px", fontSize: 11.5, cursor: "pointer" }}
                        >View Details</button>
                      </div>
                    </Popup>
                  </CircleMarker>
                );
              })}
            </MapContainer>
          </div>
          <div className="absolute bottom-3 right-3 z-[500] text-[9.5px] text-[#5B6472] bg-white/90 px-2 py-1 rounded-sm">
            © OpenStreetMap contributors · Panchayat markers are schematic — replace with real GeoJSON boundaries
          </div>
        </Card>

        {/* side panel: legend + layers + selected detail */}
        <div className="col-span-12 lg:col-span-3 flex flex-col gap-4">
          <Card>
            <div className="text-[12.5px] text-[#1C2430] mb-2">Predicted Rainfall (mm)</div>
            {[["#123A54", "≥ 60"], ["#1B587F", "45 – 60"], ["#2E6F95", "30 – 45"], ["#6FA3BE", "15 – 30"], ["#C3DBE5", "< 15"]].map(([c, l]) => (
              <div key={l} className="flex items-center gap-2 py-0.5 text-[11.5px] text-[#5B6472]">
                <span className="w-3 h-3 rounded-full inline-block" style={{ background: c }} /> {l} mm
              </div>
            ))}
          </Card>

          <Card>
            <div className="text-[12.5px] text-[#1C2430] mb-2">Layers</div>
            {LAYER_OPTIONS.map((l) => (
              <label key={l.key} className="flex items-center gap-2 py-1 text-[12px] text-[#3B4451] cursor-pointer">
                <input type="checkbox" checked={layers[l.key]} onChange={() => toggleLayer(l.key)} className="accent-[#2E6F95]" />
                {l.label}
              </label>
            ))}
          </Card>

          <Card>
            <div className="text-[12.5px] text-[#1C2430] mb-2">Risk Level</div>
            {[["#43714B", "Low"], ["#C08A3E", "Moderate"], ["#A6483A", "High"]].map(([c, l]) => (
              <div key={l} className="flex items-center gap-2 py-0.5 text-[11.5px] text-[#5B6472]">
                <span className="w-3 h-3 rounded-full inline-block" style={{ background: c }} /> {l}
              </div>
            ))}
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[12.5px] text-[#1C2430]">{selected.name}</span>
              <span className="text-[10.5px] px-2 py-0.5 rounded-full" style={{ background: riskOf(selected).bg, color: riskOf(selected).color }}>{riskOf(selected).label}</span>
            </div>
            <div className="text-[11.5px] text-[#5B6472] space-y-1">
              <div>Predicted Rainfall: <b className="text-[#1C2430]">{selected.rainfall} mm</b></div>
              <div>Temp / Humidity: <b className="text-[#1C2430]">{selected.temp}°C / {selected.humidity}%</b></div>
              <div>Confidence: <b className="text-[#1C2430]">{selected.confidence}%</b></div>
            </div>
            <a href="#/forecast" className="text-[11.5px] text-[#2E6F95] flex items-center gap-1 pt-2">View Full Forecast <ChevronRight size={12} /></a>
          </Card>
        </div>
      </div>
    </PageShell>
  );
}
